<template>
  <div>
    <div class="vehicle">
      <div>
        <div class="vehicle_text">车辆列表</div>
        <div class="vehicle_head">
          <div>
            <el-button size="small" class="vehicle_btn">添加车辆</el-button>
          </div>
          <div>
            <el-input
              size="small"
              placeholder="请输入内容"
              prefix-icon="el-icon-search icons"
              v-model="input2"
            >
            </el-input>
          </div>
        </div>
      </div>
      <div class="vehicle_list">
        <div class="vehicle_list_item" @click="jumpVideo">
          <el-card class="vehicle_list_item_card">
            <div class="vehicle_list_item_img">
              <img
                src="../../assets/vhicleList/vehicleList.png"
                alt=""
                srcset=""
              />
            </div>
            <div class="vehicle_list_item_title">CP-0001</div>
            <div class="vehicle_list_item_role">
              <span><i></i></span>
              <span class="vehicle_list_item_role_text">角色：</span>
              <span class="vehicle_list_item_role_text">司机</span>
            </div>
            <div class="vehicle_list_item_role">
              <span></span>
              <span class="vehicle_list_item_role_text">车次：</span>
              <span class="vehicle_list_item_role_text">1002</span>
              <span class="vehicle_list_item_role_text">...</span>
            </div>
          </el-card>
        </div>
        <div class="vehicle_list_item">
          <el-card class="vehicle_list_item_card">
            <div class="vehicle_list_item_img">
              <img
                src="../../assets/vhicleList/vehicleList.png"
                alt=""
                srcset=""
              />
            </div>
            <div class="vehicle_list_item_title">CP-0001</div>
            <div class="vehicle_list_item_role">
              <span><i></i></span>
              <span class="vehicle_list_item_role_text">角色：</span>
              <span class="vehicle_list_item_role_text">司机</span>
            </div>
            <div class="vehicle_list_item_role">
              <span></span>
              <span class="vehicle_list_item_role_text">车次：</span>
              <span class="vehicle_list_item_role_text">1002</span>
              <span class="vehicle_list_item_role_text">...</span>
            </div>
          </el-card>
        </div>
        <div class="vehicle_list_item">
          <el-card class="vehicle_list_item_card">
            <div class="vehicle_list_item_img">
              <img
                src="../../assets/vhicleList/vehicleList.png"
                alt=""
                srcset=""
              />
            </div>
            <div class="vehicle_list_item_title">CP-0001</div>
            <div class="vehicle_list_item_role">
              <span><i></i></span>
              <span class="vehicle_list_item_role_text">角色：</span>
              <span class="vehicle_list_item_role_text">司机</span>
            </div>
            <div class="vehicle_list_item_role">
              <span></span>
              <span class="vehicle_list_item_role_text">车次：</span>
              <span class="vehicle_list_item_role_text">1002</span>
              <span class="vehicle_list_item_role_text">...</span>
            </div>
          </el-card>
        </div>
        <div class="vehicle_list_item">
          <el-card class="vehicle_list_item_card">
            <div class="vehicle_list_item_img">
              <img
                src="../../assets/vhicleList/vehicleList.png"
                alt=""
                srcset=""
              />
            </div>
            <div class="vehicle_list_item_title">CP-0001</div>
            <div class="vehicle_list_item_role">
              <span><i></i></span>
              <span class="vehicle_list_item_role_text">角色：</span>
              <span class="vehicle_list_item_role_text">司机</span>
            </div>
            <div class="vehicle_list_item_role">
              <span></span>
              <span class="vehicle_list_item_role_text">车次：</span>
              <span class="vehicle_list_item_role_text">1002</span>
              <span class="vehicle_list_item_role_text">...</span>
            </div>
          </el-card>
        </div>
        <div class="vehicle_list_item">
          <el-card class="vehicle_list_item_card">
            <div class="vehicle_list_item_img">
              <img
                src="../../assets/vhicleList/vehicleList.png"
                alt=""
                srcset=""
              />
            </div>
            <div class="vehicle_list_item_title">CP-0001</div>
            <div class="vehicle_list_item_role">
              <span><i></i></span>
              <span class="vehicle_list_item_role_text">角色：</span>
              <span class="vehicle_list_item_role_text">司机</span>
            </div>
            <div class="vehicle_list_item_role">
              <span></span>
              <span class="vehicle_list_item_role_text">车次：</span>
              <span class="vehicle_list_item_role_text">1002</span>
              <span class="vehicle_list_item_role_text">...</span>
            </div>
          </el-card>
        </div>
        <div class="vehicle_list_item">
          <el-card class="vehicle_list_item_card">
            <div class="vehicle_list_item_img">
              <img
                src="../../assets/vhicleList/vehicleList.png"
                alt=""
                srcset=""
              />
            </div>
            <div class="vehicle_list_item_title">CP-0001</div>
            <div class="vehicle_list_item_role">
              <span><i></i></span>
              <span class="vehicle_list_item_role_text">角色：</span>
              <span class="vehicle_list_item_role_text">司机</span>
            </div>
            <div class="vehicle_list_item_role">
              <span></span>
              <span class="vehicle_list_item_role_text">车次：</span>
              <span class="vehicle_list_item_role_text">1002</span>
              <span class="vehicle_list_item_role_text">...</span>
            </div>
          </el-card>
        </div>
        <div class="vehicle_list_item">
          <el-card class="vehicle_list_item_card">
            <div class="vehicle_list_item_img">
              <img
                src="../../assets/vhicleList/vehicleList.png"
                alt=""
                srcset=""
              />
            </div>
            <div class="vehicle_list_item_title">CP-0001</div>
            <div class="vehicle_list_item_role">
              <span><i></i></span>
              <span class="vehicle_list_item_role_text">角色：</span>
              <span class="vehicle_list_item_role_text">司机</span>
            </div>
            <div class="vehicle_list_item_role">
              <span></span>
              <span class="vehicle_list_item_role_text">车次：</span>
              <span class="vehicle_list_item_role_text">1002</span>
              <span class="vehicle_list_item_role_text">...</span>
            </div>
          </el-card>
        </div>
        <div class="vehicle_list_item">
          <el-card class="vehicle_list_item_card">
            <div class="vehicle_list_item_img">
              <img
                src="../../assets/vhicleList/vehicleList.png"
                alt=""
                srcset=""
              />
            </div>
            <div class="vehicle_list_item_title">CP-0001</div>
            <div class="vehicle_list_item_role">
              <span><i></i></span>
              <span class="vehicle_list_item_role_text">角色：</span>
              <span class="vehicle_list_item_role_text">司机</span>
            </div>
            <div class="vehicle_list_item_role">
              <span></span>
              <span class="vehicle_list_item_role_text">车次：</span>
              <span class="vehicle_list_item_role_text">1002</span>
              <span class="vehicle_list_item_role_text">...</span>
            </div>
          </el-card>
        </div>
        <div class="vehicle_list_item">
          <el-card class="vehicle_list_item_card">
            <div class="vehicle_list_item_img">
              <img
                src="../../assets/vhicleList/vehicleList.png"
                alt=""
                srcset=""
              />
            </div>
            <div class="vehicle_list_item_title">CP-0001</div>
            <div class="vehicle_list_item_role">
              <span><i></i></span>
              <span class="vehicle_list_item_role_text">角色：</span>
              <span class="vehicle_list_item_role_text">司机</span>
            </div>
            <div class="vehicle_list_item_role">
              <span></span>
              <span class="vehicle_list_item_role_text">车次：</span>
              <span class="vehicle_list_item_role_text">1002</span>
              <span class="vehicle_list_item_role_text">...</span>
            </div>
          </el-card>
        </div>
        <div class="vehicle_list_item">
          <el-card class="vehicle_list_item_card">
            <div class="vehicle_list_item_img">
              <img
                src="../../assets/vhicleList/vehicleList.png"
                alt=""
                srcset=""
              />
            </div>
            <div class="vehicle_list_item_title">CP-0001</div>
            <div class="vehicle_list_item_role">
              <span><i></i></span>
              <span class="vehicle_list_item_role_text">角色：</span>
              <span class="vehicle_list_item_role_text">司机</span>
            </div>
            <div class="vehicle_list_item_role">
              <span></span>
              <span class="vehicle_list_item_role_text">车次：</span>
              <span class="vehicle_list_item_role_text">1002</span>
              <span class="vehicle_list_item_role_text">...</span>
            </div>
          </el-card>
        </div>
      </div>
      <!--  -->
      <div class="vehicle_Pagination">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          background
          layout="prev, pager, next"
          :total="100"
          size="medium"
        >
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      input2: "",
    };
  },
  methods: {
    //跳转
      jumpVideo(){
        this.$router.push('emergency_video')
      },
    //   
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    },
  },
};
</script>

<style lang="less">
.vehicle {
  //   display: flex;
  .vehicle_text {
    width: 128px;
    height: 45px;
    font-size: 32px;
    font-weight: 600;
    display: flex;
  }
  .vehicle_head {
    margin-top: 0.2667rem;
    display: flex;
    justify-content: space-between;
    .vehicle_btn {
      font-size: 24px;
      background-color: #004da1;
      color: #fff;
    }
    .icons {
      //   margin-left: 50px;
    }
  }
  .vehicle_list {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    background-color: #f9f9fb;
    margin-top: 0.2667rem;
    padding: 0.2rem;
    .vehicle_list_item {
      width: 300px;
      height: 450px;
      //   margin-right: 25px;
      .vehicle_list_item_card {
        border-radius: 5%;
        text-align: left;
        .vehicle_list_item_img {
          width: 258px;
          height: 258px;
          img {
            width: 100%;
            height: 100%;
          }
        }
        .vehicle_list_item_title {
          font-size: 32px;
        }
        .vehicle_list_item_role {
          .vehicle_list_item_role_text {
            font-size: 28px;
            margin-top: 10px;
          }
        }
      }
    }
  }
  .el-pager li {
    display: block;
    width: 40px;
    height: 40px;
  }
  .vehicle_Pagination {
    .el-pager li {
      display: inline-block;
      width: 60px;
      height: 60px;
      line-height: 60px;
      border-radius: 8px !important;
    }
    .el-pagination .btn-next .el-icon,
    .el-pagination .btn-prev .el-icon {
    //   border: 0 !important;//////
      font-size: 40px;
      line-height: 60px;
      width: 60px;
      height: 60px;
      background-color: #fff;
      border: 1px solid #eee;
      border-radius: 8px !important;
      margin-top: -2px;
    }
    .el-pagination.is-background .el-pager li:not(.disabled).active {
      background-color: #004da1;
      color: #fff !important;
    }
    .el-pager li:hover {
      color: #004da1 !important;
    }

    .white-list-tool.is-background .btn-next .el-icon-arrow-right {
      margin: 0 auto;
    }
    .white-list-tool.is-background .btn-prev .el-icon-arrow-left {
      margin: 0 auto;
    }
    .el-pagination.is-background .btn-next,
    .el-pagination.is-background .btn-prev,
    .el-pagination.is-background .el-pager li {
      background-color: #fff;
      border: 1px solid #eee;
    }
  }
}
</style>